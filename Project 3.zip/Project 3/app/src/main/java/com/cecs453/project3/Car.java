package com.cecs453.project3;

public class Car {
    public final String imgURL, mileage, price, carID;

    public Car(String imgURL, String mileage, String price, String carID) {
        this.imgURL = imgURL;
        this.mileage = mileage;
        this.price = price;
        this.carID = carID;
    }
}
